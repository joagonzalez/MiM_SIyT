Instalar requerimientos:

sudo apt install libsnappy-dev 
pip3 install -r requirements.txt

Estructura directorios con reporte de archivos (Si no existen se crean en la carpeta de ejecución):

- reports
|
|--- json
|--- parquet


Ejecución script:

Manual: 
# python3 api.py 

Docker:
# docker build -t mim_tp1:1.x .
# docker run -v ./reports:/app/reports mim_tp1:1.x


Notas:

- Se crean archivos con lo recibido desde API en reports/json con timestamp de cada iteración
- Se crean archivos parquet con timestamp de cada ejecucion + '_i' ya que se parte la salida en chunks de a 1000
- Se pregunta cantidad de iteraciones a realizar
- Se pregunta al usuario si desea insertar temetria en influxdb
- Se pregunta a usuario si desea enviar notificación de corrida a telegram bot
- Tiempo de espera entre interaciones hardcodeado a 30s
- Posibilidad de ejecutar en Docker container


Estudiantes:

- Victoria Marcos (victoriamarcos@hotmail.com)
- Juana Lopez Arbol (juanalopezarbol@hotmail.com)
- Joaquin Gonzalez (joagonzalez@gmail.com)
- Julieta Santarelli (julisantarelli@hotmail.com)


